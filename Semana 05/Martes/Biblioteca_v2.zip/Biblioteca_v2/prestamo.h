#pragma once
#include "fecha.h"

using namespace std;

class Prestamo
{

/// el libro que se prest�, a qu� socio se lo prest�, cu�l fue el d�a del pr�stamo y cu�l fue la fecha de devoluci�n.

private:
    int _isbn;
    int _idSocio;
    Fecha _prestamo;
    Fecha _devolucion;

public:
    void setNumLibro(int numLibro);
    int getNumLibro();
    void setIdSocio(int idSocio);
    int getIdSocio();
    void setPrestamo(Fecha prestamo);
    Fecha getPrestamo();
    void setDevolucion(Fecha devolucion);
    Fecha getdevolucion();

    void cargar();
    void mostrar(int formato);

};
